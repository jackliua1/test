<?php
namespace application\admin\model;
use think\console\command\make\Model;

class AdminHome extends Model{


}