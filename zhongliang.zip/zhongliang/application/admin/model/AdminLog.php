<?php

/**
 *  
 * @file   AdminLog.php  
 * @date   2016-10-9 17:29:09 
 * @author Zhenxun Du<5552123@qq.com>  
 * @version    SVN:$Id:$ 
 */
class AdminLog extends think\Model {
    

}
