<?php
namespace application\admin\model;

use think\Model;
class Classs extends Model{



}





