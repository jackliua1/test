<?php
namespace application\admin\model;

use think\Model;
class Commodity extends Model{



}