<?php
namespace application\home\model;
use think\console\command\make\Model;

class AdminHome extends Model{
public function insert(){

}
}