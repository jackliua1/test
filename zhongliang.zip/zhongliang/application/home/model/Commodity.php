<?php
namespace application\home\model;

use think\Model;
class Commodity extends Model{



}