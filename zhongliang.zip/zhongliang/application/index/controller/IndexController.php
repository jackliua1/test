<?php

/**
 *  
 * @file   Index.php  
 * @date   2016-8-23 16:03:10 
 * @author Zhenxun Du<5552123@qq.com>  
 * @version    SVN:$Id:$ 
 */  

namespace application\index\controller;
use think\Db;
use think\model;
use think\db\Query;
class IndexController extends CommonController{
    /**
     *
     */

    public $user_id;
    public $u_id;
    public function __construct()
    {
        parent::__construct();
        $this->user_id=  session('user_id');
        $data= db('admin')->where('id',$this->user_id)->find();
        $this->assign('id',$this->user_id);
        $this->u_id=$data['uid'];
    }

    public function index(){
       
        return $this->fetch();
    }
    //显示商家所有的商品
    public function gouhuo(){

        $id=  session('user_id');
        $data= db('admin')->where('id',$id)->find();
        $this->assign('id', $id);
       $date['uid']=$data['uid'];
        $dates= db('classs')->where('uid',$date['uid'])->select();
       $data= db('commodity')->where('admin_id',$date['uid'])->select();
        $this->assign('dates', $dates);
        $this->assign('data', $data);
        return $this->fetch();
    }
    //库存列表
    public function kucunliebiao(){
        //登录id
        $id=  session('user_id');
        $info = db('goods')->where('good_id',$id)->select();
        $das=$info['uid'];
        $das['time']=date('Y-m-d');
//        var_dump($das);
        $infr= Db::table('zxcms_goods')
            ->alias('a')
            ->join('zxcms_commodity w','a.uid = w.id')
            ->where($das)
            ->select();
        $this->assign('infr', $infr);
        return $this->fetch();
    }

    //购货单
    public function book(){
        //获取用户id
        $id=  session('user_id');
        $info = db('goods')->where('good_id',$id)->select();
        $das=$info['uid'];
        $das['time']=date('Y-m-d');
//        var_dump($das);
       $infr= Db::table('zxcms_goods')
                ->alias('a')
                ->join('zxcms_commodity w','a.uid = w.id')
                ->where($das)
                ->select();

//        var_dump($infr);die;

        $this->assign('infr', $infr);

        return $this->fetch('book');

    }
    //库存盘点
    public function inventory(){

        return $this->fetch();
    }
    //添加商品的数据库
    public function adds(){
        $id=  session('user_id');
        if($_POST) {
            $post = $_POST;
            //对数组进行循环
            $goodsarr = array();
            $i=$j=0;
            foreach($post['arr'] as $k=>$v){

                if($v['name']=='number'){
                    //如果数量大于0 记录数量
                    if($v['value']>0){
                        $goodsarr[$i]['number'] = $v['value'];
                        $i++;
                    }
                }else{
                    //记录id
                    if($goodsarr[$j]['number']>0){
                        $goodsarr[$j]['uid'] = $v['value'];
                        $j++;

                    }
                }
            }
        }
//        var_dump($goodsarr);die;
        foreach ($goodsarr as $k=>$v){
                if($k<0){
                    $k++;
                }
        }
//        var_dump($k);die;
        for($i=0;$i<$k+1;$i++){
            $goodsarr[$i]['time']=date('Y-m-d');
        }
        for($i=0;$i<$k+1;$i++){
            $goodsarr[$i]['good_id']=$id;
        }
//        var_dump($goodsarr);die;

            $res = model('goods')->saveAll($goodsarr);
//        return $res;
         echo json_encode($res);

    }
    //购货单查询
    public function edis(){

        $data = input('');

        $infr= Db::table('zxcms_goods')
            ->alias('a')
            ->join('zxcms_commodity w','a.uid = w.id')
            ->where($data)
            ->select();
//        var_dump($infr);die;
        $this->assign('infr', $infr);
        return $this->fetch('book');
    }
    //库存查询
    public function dis(){
        $id=  session('user_id');
        $data = input('');
        $info = db('goods')->where($data)->where('uid',$id)->select();
        $this->assign('info', $info);
        return $this->fetch('kucunliebiao');


    }

    //切换分类
    public function qhattr(){
        $attr_name = $_POST['attr_name'];
        if(!$attr_name){
            $data['status'] = 0;
            $data['msg'] = "非法操作";
            echo json_encode($data);
        }
        $where = "uid=".$this->u_id;
        if($attr_name != '全部'){
            $where .= " and ys='$attr_name'";
        }
        $goods_list = db('commodity')->where($where)->select();
//        var_dump($goods_list);
        $data['status'] = 1;
        $data['data'] = $goods_list;
        echo json_encode($data);
    }
    public function login(){
        session('user_name', null);
        session('user_id', null);
        cookie('user_name', null);
        cookie('user_id', null);
        $this->success('', 'login/index');

    }
//    function json2array ($er)
//    {
//
//        if (!is_array($er)) return array ();
//
//        $ret_arr = array ();
//        foreach ($er as $key => $value) {
//            $ret_arr[$value[0]] = $value[1];
//        }
//        return $ret_arr;
//    }
}