<?php
namespace application\index\controller;
class KucunController extends CommonController{

public function kucunliebiao(){

    return $this->fetch();
}





}




