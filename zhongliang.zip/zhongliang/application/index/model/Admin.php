<?php
namespace application\index\model;
use think\db;
use think\Model;
class Admin extends Model{



}










