<?php
namespace application\index\model;
use think\Model;
class Goods extends Model{


}











