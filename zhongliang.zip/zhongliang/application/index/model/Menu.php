<?php
namespace application\index\model;
use think\Model;
class Menu extends Model{

public function menu(){

}


}